
// 1. Exercise - Bubble sort

func __bubbleSort<T: Comparable>(_ array: Array<T>) -> Array<T> {
    var sorted = array, n = sorted.count
    repeat {
        var newn = 0
        for i in stride(from: 1, to: n, by: 1) {
            if sorted[i-1] > sorted[i] {
                swap(&sorted[i-1], &sorted[i])
                newn = i
            }
        }
        n = newn
    } while n != 0

    return sorted
}

extension Array where Element: Comparable {
    func bubbleSort() -> Array<Element> {
        return __bubbleSort(self)
    }
}

[4, 3, 5, 1, 2].bubbleSort() == [1, 2, 3, 4, 5]

// 2. Exercise - Revert String in place

extension String {
    mutating func reverse() {
        var startIndex = self.startIndex, endIndex = self.endIndex
        while startIndex != endIndex {
            let nextIndex = self.index(after: startIndex)
            let precedingIndex = self.index(before: endIndex)
            let startString = self[startIndex..<nextIndex]
            let endString = self[precedingIndex..<endIndex]

            self.replaceSubrange(startIndex..<nextIndex, with: endString)
            self.replaceSubrange(precedingIndex..<endIndex, with: startString)

            startIndex = nextIndex
            endIndex = precedingIndex
        }
    }
}

var testString = "Do not use a palindrome for testing!"
testString.reverse()
